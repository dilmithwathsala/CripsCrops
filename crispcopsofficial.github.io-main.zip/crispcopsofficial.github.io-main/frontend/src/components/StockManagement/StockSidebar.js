import React from 'react';

function StockSidebar(){
    return(
        <div></div>
    )
}
export default StockSidebar